var searchData=
[
  ['extra',['Extra',['../de/d75/classneuron_1_1entities_1_1Extra.html',1,'neuron::entities']]]
];
