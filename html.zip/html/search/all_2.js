var searchData=
[
  ['data',['Data',['../df/d03/classneuron_1_1entities_1_1Data.html',1,'neuron::entities']]],
  ['datarequest',['DataRequest',['../df/d08/classneuron_1_1web_1_1DataRequest.html',1,'neuron::web']]]
];
