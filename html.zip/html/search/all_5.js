var searchData=
[
  ['maincontroller',['MainController',['../de/ddf/classneuron_1_1controller_1_1MainController.html',1,'neuron::controller']]]
];
