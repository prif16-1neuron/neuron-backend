var indexSectionsWithContent =
{
  0: "acdegmnw",
  1: "acdemnw",
  2: "cg",
  3: "gn"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Pages"
};

