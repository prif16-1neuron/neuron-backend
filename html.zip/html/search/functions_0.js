var searchData=
[
  ['calculate',['calculate',['../da/d29/classneuron_1_1calculator_1_1Calculator.html#af2169a8fa98450acbf4bd295a6328f78',1,'neuron::calculator::Calculator']]]
];
