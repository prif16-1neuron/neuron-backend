var searchData=
[
  ['getting_20started',['Getting Started',['../dc/de6/md_HELP.html',1,'']]]
];
