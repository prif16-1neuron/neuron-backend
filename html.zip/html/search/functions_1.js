var searchData=
[
  ['getautocalculations',['getAutoCalculations',['../de/ddf/classneuron_1_1controller_1_1MainController.html#a9bb020e19ae52933e586e9c0e302826b',1,'neuron::controller::MainController']]],
  ['getcalculations',['getCalculations',['../de/ddf/classneuron_1_1controller_1_1MainController.html#a178300c3c52f707b61cad563f3ddf874',1,'neuron::controller::MainController']]]
];
