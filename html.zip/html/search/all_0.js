var searchData=
[
  ['autodata',['AutoData',['../d1/dbe/classneuron_1_1entities_1_1AutoData.html',1,'neuron::entities']]],
  ['autodatarequest',['AutoDataRequest',['../dc/d2e/classneuron_1_1web_1_1AutoDataRequest.html',1,'neuron::web']]]
];
