var searchData=
[
  ['neuronapplication',['NeuronApplication',['../df/d73/classneuron_1_1NeuronApplication.html',1,'neuron']]],
  ['neuronapplicationtests',['NeuronApplicationTests',['../d1/d38/classneuron_1_1NeuronApplicationTests.html',1,'neuron']]]
];
